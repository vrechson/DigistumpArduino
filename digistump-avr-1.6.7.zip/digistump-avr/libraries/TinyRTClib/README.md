TinyRTClib
==========

DS1307's Arduino Adafruit library modified to run on Digispark's attiny85.

I've searched everywhere for a DS1307 library that could work on my Digispark but found none.

This is the Adafruit version (https://github.com/adafruit/RTClib) with their examples modified to work on Digispark's attiny85.

**I'm unable to push the files into the right folders by now. That's why I've them renamed to the folders name and slashs...
**Will try to add to the right place later.
